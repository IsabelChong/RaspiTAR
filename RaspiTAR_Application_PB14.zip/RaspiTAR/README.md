This board contains the main source codes for Isabel and Xin Shi's Biomedical Product Design (BPD) 
module in Ngee Ann Polytechnic for their year 3 project. The product makes use of Amazon Web Services (AWS) 
and Google APIs to connect the system to the internet and databases.

RaspiTAR stands for Raspberyy-Pi based Temperature Attendance Recorder. 
This project was innovated due to the The objective of this project is to first reduce the cost of 
temperature crowd screening systems, using MLX90641 Thermal Sensor Array. In addition, it is able 
to take the attendance records of students via face recognition using the PiCamera V2.1.

Creators: Isabel Chong (IsabelChong.CYJI@gmail.com) Tan Xin Shi (XinShi2001@gmail.com)

client_key.json is not present in the board as it contains confidential google credentials. 
Please use your own should you need to use this app.
